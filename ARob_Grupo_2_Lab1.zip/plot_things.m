%clear all;
%close all;

%NOTA: para este c�digo funcionar:
%
%      Nome dos ficheiros: 
%
%      1 -  devem come�ar com a indica��o do k e do h, e deve estar
%      exatamente da mesma forma escrito para o experimental e o teorico
%      
%      2 -  depois do k e h, dizer "_teorico" ou "_experimental"
%      OBRIGAT�RIO

path(pathdef);
path = [pwd '\Dados\'];

i=1;
previous = 'lol';

files = dir(strcat(path,'*.mat'));
for file = files'
    dados(i).nome = file.name;
    dados(i).KH = erase(file.name,"_teorico.mat");
    dados(i).KH = erase(dados(i).KH,"_experimental.mat");
    dados(i).KH = erase(dados(i).KH,"_xpedido.mat");
    dados(i).KH = strrep(dados(i).KH,'_',' ');
    dados(i).dado = load(strcat(path,file.name));
    i = i+1;
end

for coisa = dados
    if(strcmp(previous, coisa.KH) == 1) % o anterior tbm era os mesmo dados
        plot(coisa.dado.ans(1,:),coisa.dado.ans(2,:));
        xlabel('tempo [s]');
        ylabel('altitude [m]');
        axis([20,50,0.6,MAX]);
        legend('Experimental', 'Teorico', 'Pedido', 'Location', 'southeast');
    else
        figure();
        MAX = max(coisa.dado.ans(2,:) + 0.15);
        plot(coisa.dado.ans(1,:),coisa.dado.ans(2,:));
        hold on;
        %title(coisa.KH);
        %hold off;
    end
    previous = coisa.KH;
    
end